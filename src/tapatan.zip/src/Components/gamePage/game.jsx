import React, { Component } from "react";
import botRobot from "../../assets/images/botPlayer.jpg";
import userRobot from "../../assets/images/userPlayer.jpg";
import menuIcon from "../../assets/images/menuIcon.png";
import "./gamePage.css";

class Game extends Component {
  state = {
    ID: {
      botId: 0,
      userId: 1,
    },
    playerpositions: [1, 2, 3, 4, 5, 6, 7, 8, 9],
    playerImgMove: "",
    selectedImg: "",
    playerImg1: "",
    playerImg2: "",
    playerImg3: "",
  };

  handlepositions = (e) => {
    console.log(e.target.id);
    this.setState({ selectedImg: e.target.id });
  };

  handleChangeImgMove = (e, key) => {
    console.log(e.target.value);
    if (e.target.value === 1) {
      this.setState({ [this.state.selectedImg]: "player-cell1" });
    }
    if (e.target.value === 2) {
      this.setState({ [this.state.selectedImg]: "player-cell2" });
    }
    if (e.target.value === 3) {
      this.setState({ [this.state.selectedImg]: "player-cell3" });
    }
    if (e.target.value === 4) {
      this.setState({ [this.state.selectedImg]: "player-cell4" });
    }
    if (e.target.value === 5) {
      this.setState({ [this.state.selectedImg]: "player-cell5" });
    }
    if (e.target.value === 6) {
      this.setState({ [this.state.selectedImg]: "player-cell6" });
    }
    if (e.target.value === 7) {
      this.setState({ [this.state.selectedImg]: "player-cell7" });
    }
    if (e.target.value === 8) {
      this.setState({ [this.state.selectedImg]: "player-cell8" });
    }
    if (e.target.value === 9) {
      this.setState({ [this.state.selectedImg]: "player-cell9" });
    }
  };

  handleReset = () => {
    this.setState({
      playerImg1: "",
      playerImg2: "",
      playerImg3: "",
    });
  };

  handleOnePlayer = () => {
    console.log("one ");
  };

  render() {
    const { playerpositions, playerImgMove } = this.state;
    return (
      <>
        <nav className="navbar navbar-dark">
          <span className="adtag">Yandex Games</span>
          <span className="adtag">Tapatan</span>
          <div className="navicons">
            <span>
              <img
                src={menuIcon}
                className="yanimg"
                onClick={this.handleOnePlayer}
              />
            </span>
            <span>
              <i className="fa fa-solid fa-bars ficonst"></i>
            </span>
            <span>
              <i className="fa-solid fa-down-left-and-up-right-to-center ficonst"></i>
            </span>
          </div>
        </nav>
        <div className="main-bg">
          <div className="grid">
            <img
              className="robo-img robo-img-first "
              src={botRobot}
              alt="robo"
            />
            <img
              className="robo-img robo-img-second"
              src={botRobot}
              alt="robo"
            />
            <img className="robo-img robo-img-last" src={botRobot} alt="robo" />
            {Array.from({ length: 3 }).map((_, rowIndex) => (
              <div key={rowIndex} className="cell-row">
                {Array.from({ length: 3 }).map((_, colIndex) => (
                  <div key={colIndex} className="cell">
                    <span className="placeNumber">
                      {rowIndex * 3 + colIndex + 1}
                    </span>
                  </div>
                ))}
              </div>
            ))}

            <img
              id="playerImg1"
              className={`player-img player-img-first ${this.state.playerImg1}`}
              src={userRobot}
              alt="player"
              onClick={(e) => this.handlepositions(e)}
            />
            <img
              id="playerImg2"
              className={`player-img player-img-second ${this.state.playerImg2}`}
              src={userRobot}
              alt="player"
              onClick={(id) => this.handlepositions(id)}
            />
            <img
              id="playerImg3"
              className={`player-img player-img-last ${this.state.playerImg3}`}
              src={userRobot}
              alt="player"
              onClick={(id) => this.handlepositions(id)}
            />
          </div>
          <button onClick={() => this.handleReset()}>reset</button>

          <div className="possible-moves">
            <p>Possible moves are:</p>
            <ul>
              {playerpositions.map((position, index) => (
                <li
                  key={index}
                  value={position}
                  onClick={(e, index) => this.handleChangeImgMove(e, index)}
                >
                  {position}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </>
    );
  }
}

export default Game;
