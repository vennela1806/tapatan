import React, { Component } from "react";
import botRobot from "../../assets/images/gameStartbotPlayer.png";
import robo2img from "../../assets/images/robo2img.png";
import globe from "../../assets/images/globeimg.png";
import menuIcon from "../../assets/images/menuIcon.png";
import { Link } from "react-router-dom";
import { pushRoute } from "../Services/pushRoute";

import "./startgame.css";

class StartGame extends Component {
  state = {};

  handleOnePlayer = () => {
    const { navigate } = this.props;
    console.log("one ");
    navigate("/game");
  };
  render() {
    console.log(this.props);
    return (
      <>
        <nav className="navbar navbar-dark">
          <span className="startgame-adtag">Yandex Games</span>
          <span className="startgame-adtag">Tapatan</span>
          <div className="navicons">
            <span>
              <img src={menuIcon} className="yanimg" />
            </span>
            <span>
              <i className="fa-solid fa-bars ficonst"></i>
            </span>
            <span>
              <i className="fa-solid fa-down-left-and-up-right-to-center ficonst"></i>
            </span>
          </div>
        </nav>
        <div className="startgame-bg">
          <div className="menuicons">
            <Link to="">
              <span>
                <i className="fa-solid fa-bars ficons fa-2xl text-light"></i>{" "}
              </span>
            </Link>
            <span className="ficons" style={{ fontWeight: "bold" }}>
              Rank: 0
            </span>
            <span>
              <i className="fa-regular fa-star ficons fa-2xl"></i>
            </span>
            <Link to="">
              <span>
                <i className="fa-solid fa-share-nodes fa-2xl ficons text-light"></i>
              </span>
            </Link>
          </div>
          <div className="team">
            <div className="player">
              <h4>Player</h4>
            </div>
            <div>
              <h1>Tapatan</h1>
              <h5>Win with skill!</h5>
            </div>
          </div>
          <div className="card_container">
            <div className="startgame-card " onClick={this.handleOnePlayer}>
              <button className="mbtn">
                <img src={botRobot} className="gameimg" alt="roboimg" />
                <h2>One player</h2>
              </button>
            </div>

            <div className="startgame-card">
              <button className="mbtn">
                <img src={botRobot} className="gameimg" alt="roboimg" />
                <img src={globe} className="gameimg2" alt="globeimg" />
                <img src={robo2img} className="gameimg" alt="roboimg" />
                <h2>Multiplayer</h2>
              </button>
            </div>
          </div>
        </div>
        {/* <div id="popup-box" className="modal">
          <div className="content">
            <h4 className="menuhead">Menu</h4>
            <p>
              <i className="fa-regular fa-circle-question fa-2xl ficons2"></i>
              Help
            </p>
            <p>
              <i className="fa-solid fa-gear fa-2xl ficons2"></i>Settings
            </p>
            <p>
              <i className="fa-solid fa-user fa-2xl ficons2"></i>Developers
            </p>
            <p>
              <i className="fa-solid fa-chart-simple fa-2xl ficons2"></i>High
              Score
            </p>

            <p>Our other games</p>

            <Link to="" className="box-close">
              ×
            </Link>
          </div>
        </div> */}
        {/* <div id="popup-box1" className="modal">
          <div className="content">
            <h3>Share</h3>
            <h6>Invite Friends</h6>

            <Link to="" className="box-close">
              ×
            </Link>
          </div>
        </div> */}
      </>
    );
  }
}

export default pushRoute(StartGame);
