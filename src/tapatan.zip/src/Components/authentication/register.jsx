import React, { Component } from "react";
import { Link } from "react-router-dom";
import { pushRoute } from "../Services/pushRoute";
import Joi from "joi-browser";
import Form from "../common/form";
import { toast } from "react-toastify";
import auth from "../Services/authService";

class Register extends Form {
  state = {
    data: { name: "", username: "", password: "", confirmPassword: "" },
    type: "password",
    className: "fa-regular fa-eye-slash",
    confirmType: "password",
    confirmClassName: "fa-regular fa-eye-slash",
    errors: {},
    confirmpassworderrros: "",
  };

  schema = {
    name: Joi.string().required().label("Name").min(5).max(50),
    username: Joi.string().required().label("Email").min(5).max(250),
    password: Joi.string().required().label("Password").min(8).max(1024),
    confirmpassword: Joi.string()
      .required()
      .label("Confirm Password")
      .min(8)
      .max(1024),
  };

  handlelogin = () => {
    const { navigate } = this.props;
    navigate("/loginform");
  };

  doSubmit = async (e) => {
    const { navigate } = this.props;

    try {
      const { data } = this.state;
      if (data.password === data.confirmPassword) {
        const response = await auth.register(
          data.email,
          data.name,
          data.password,
          data.confirmPassword
        );
        navigate("/loginForm");
        toast.success(response);
      } else {
        this.setState({
          confirmpassworderrros: "Passwords should match",
        });
      }
    } catch (ex) {
      if (ex.response && ex.response.status === 400) {
        const errors = { ...this.state.errors };
        errors.name = ex.response.data;
        this.setState({ errors });
      }
    }
  };

  handleIcon = () => {
    this.state.type === "password"
      ? this.setState({
          type: "text",
          className: "fa-regular fa-eye",
        })
      : this.setState({
          type: "password",
          className: "fa-regular fa-eye-slash",
        });
  };

  handleConfirmIcon = () => {
    this.state.confirmType === "password"
      ? this.setState({
          confirmType: "text",
          confirmclassName: "fa-regular fa-eye",
        })
      : this.setState({
          confirmType: "password",
          confirmclassName: "fa-regular fa-eye-slash",
        });
  };
  render() {
    const { data, errors } = this.state;
    const { navigate } = this.props;

    return (
      <div className="login-main-bg">
        <div className="logincontainer">
          <div className="logins-card">
            <h4>Register</h4>
            <form onSubmit={this.handleSubmit} className="form-group mb-3">
              {this.renderInput(
                "name",
                "Name",
                "text",
                // "form-control",
                "name",
                "Enter Username"
              )}
              {this.renderInput(
                "username",
                "Email",
                "text",
                // "form-control",
                "username",
                "Email"
              )}

              <div class="mb-3 form-password-toggle">
                <label class="form-label" for="password">
                  Password
                </label>
                <div class="input-group input-group-merge">
                  <input
                    value={data.password}
                    onChange={this.handleChange}
                    type={this.state.type}
                    id="password"
                    // class="form-control"
                    name="password"
                    placeholder="Password"
                    aria-describedby="password"
                  />

                  <span class="eye-symbol-container" onClick={this.handleIcon}>
                    <i className={`eye-symbol ${this.state.className}`}></i>
                  </span>
                </div>
                {errors.password && (
                  <div className="alert alert-danger">{errors.password}</div>
                )}
              </div>

              <div className="mb-3 form-password-toggle">
                <label className="form-label">Confirm Password</label>
                <div className="input-group input-group-merge">
                  <input
                    value={data.confirmPassword}
                    onChange={this.handleChange}
                    type={this.state.confirmType}
                    id="confirmpassword"
                    // className="form-control"
                    name="confirmpassword"
                    placeholder="Confirm Password"
                    aria-describedby="confirmpassword"
                  />
                  <span
                    class="eye-symbol-container"
                    onClick={this.handleConfirmIcon}
                  >
                    <i
                      className={`eye-symbol ${this.state.confirmClassName}`}
                    ></i>
                  </span>
                </div>
                {this.state.confirmpassworderrros && (
                  <div className="alert alert-danger">
                    {this.state.confirmpassworderrros}
                  </div>
                )}
              </div>

              <div>
                <button className="login-button" type="submit">
                  Register Now
                </button>
              </div>
            </form>

            {/* <div className="remember-me">
              <input type="checkbox" id="remember" />
              <label for="remember" classNameName="remember">
                Remember Me
              </label>
              <span className="fpassword">
                <Link>Forgot Password ?</Link>
              </span>
            </div> */}
            <br />
            <div>
              <span className="dont-have-account">
                Already have an account ?{" "}
                <span className="sign" onClick={this.handlelogin}>
                  SignIn now
                </span>
              </span>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default pushRoute(Register);
