import React, { Component } from "react";
import { Link } from "react-router-dom";
import { pushRoute } from "../Services/pushRoute";
import Joi from "joi-browser";
import Form from "../common/form";
import { toast } from "react-toastify";
import auth from "../Services/authService";

class LoginForm extends Form {
  state = {
    data: { username: "", password: "" },
    type: "password",
    className: "fa-regular fa-eye-slash",
    errors: {},
  };

  schema = {
    username: Joi.string().required().label("Email").min(5).max(250),
    password: Joi.string().required().label("Password").min(8).max(1024),
  };

  handleRegister = () => {
    const { navigate } = this.props;
    navigate("/RegisterForm");
  };

  doSubmit = async () => {
    try {
      // const { data } = this.state;
      // const response = await auth.login(data.username, data.password);
    } catch (ex) {
      if (ex.response && ex.response.status === 400) {
        const errors = { ...this.state.errors };
        errors.username = ex.response.data;
        this.setState({ errors });
      }
    }
  };

  handleIcon = () => {
    this.state.type === "password"
      ? this.setState({
          type: "text",
          className: "fa-regular fa-eye",
        })
      : this.setState({
          type: "password",
          className: "fa-regular fa-eye-slash",
        });
  };
  render() {
    const { data, errors } = this.state;
    const { navigate } = this.props;

    return (
      <div className="login-main-bg">
        <div className="logincontainer">
          <div className="logins-card">
            <h4>Login</h4>
            <form onSubmit={this.handleSubmit} className="form-group mb-3">
              {this.renderInput(
                "username",
                "Email",
                "text",
                // "form-control",
                "username",
                "Email"
              )}

              <div class="mb-3 form-password-toggle">
                <label class="form-label" for="password">
                  Password
                </label>
                <div class="input-group input-group-merge">
                  <input
                    value={data.password}
                    onChange={this.handleChange}
                    type={this.state.type}
                    id="password"
                    // class="form-control"
                    name="password"
                    placeholder="Password"
                    aria-describedby="password"
                  />

                  <span class="eye-symbol-container" onClick={this.handleIcon}>
                    <i className={`eye-symbol ${this.state.className}`}></i>
                  </span>
                </div>
                {errors.password && (
                  <div className="alert alert-danger">{errors.password}</div>
                )}
              </div>

              <div>
                <button className="login-button" type="submit">
                  Login Now
                </button>
              </div>
            </form>

            {/* <div className="remember-me">
              <input type="checkbox" id="remember" />
              <label for="remember" classNameName="remember">
                Remember Me
              </label>
              <span className="fpassword">
                <Link>Forgot Password ?</Link>
              </span>
            </div> */}
            <br />
            <div>
              <span className="dont-have-account">
                Don't have an account ?{" "}
                <span className="sign" onClick={this.handleRegister}>
                  Signup now
                </span>
              </span>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default pushRoute(LoginForm);
