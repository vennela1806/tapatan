// import http from "./httpService";
// import helpers from "./cryptos";
// import jwtDecode from "jwt-decode";

// const apiEndpoint = process.env.REACT_APP_API_URL;
// const tokenkey = "token";

// http.setJwt(getJwt());

// export function getCurrentUser() {
//   try {
//     const jwt = localStorage.getItem(tokenkey);
//     return jwtDecode(jwt);
//   } catch (ex) {
//     return null;
//   }
// }

// export function getJwt() {
//   return localStorage.getItem(tokenkey);
// }

// export async function login(email, password) {
//   const loginobj = { email, password };

//   const drreqpob = helpers.encryptobj(loginobj);
//   const data = await http.post(apiEndpoint + "/admin/adminlogin", {
//     enc: drreqpob,
//   });

//   if (data.data) {
//     var dd = helpers.decryptobj(data.data);

//     return dd;
//   }
// }

// export default {
//   login,
//   // Register,
// };
